document.addEventListener("deviceready", function(){
	var autoHideNavigationBar = false;
	window.navigationbar.setUp(autoHideNavigationBar);		
}, false);

//window.navigationbar.hide();