function doLogoff(){
    window.localStorage.clear();
    window.location.replace("../pages/login.html");
}