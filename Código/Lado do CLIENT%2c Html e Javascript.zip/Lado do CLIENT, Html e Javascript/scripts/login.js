$(document).ready(function() {

    var phpLoginUrl = 'http://azanbertre.com/projetointegrador/index.php'; //"http://localhost/projetointegrador/index.php";

    let user = window.localStorage.getItem("username");
    let pass = window.localStorage.getItem("password");

    if(user!=null & pass!=null){
        window.location.replace("../pages/content.html");
        /*
        var dataString="username="+user+"&password="+pass+"&login=";
        $.ajax({
            type: "POST",
            url: phpLoginUrl,
            data: dataString,
            crossDomain: true,
            cache: false,
            beforeSend: function(){ 
                document.getElementById('submit').innerHTML = 'Conectando...';
            },
            success: function(data){
                if(data){
                    window.location.replace("../pages/content.html");
                }
                else{
                    document.getElementById('submit').innerHTML = 'Login';
                }
            }
        });*/
    }
    else{
        $("#submit").click(function(){

            var username=$.trim($("#username").val());
            var password=$.trim($("#password").val());
            var dataString="username="+username+"&password="+password+"&login=";
            if(username.length>0 & password.length>0){
                $.ajax({
                    type: "POST",
                    url: phpLoginUrl,
                    data: dataString,
                    crossDomain: true,
                    cache: false,
                    beforeSend: function(){ 
                        document.getElementById('submit').innerHTML = 'Conectando...';
                    },
                    success: function(data){
                        //document.getElementById('msg').innerHTML = "TENTANDO CONECTAR";
                        if(data){
                            window.localStorage.setItem("username", username);
                            window.localStorage.setItem("password", password);

                            window.location.replace("../pages/content.html");
                            document.getElementById('submit').innerHTML = 'LOGIN';
                        }
                        else{
                            document.getElementById('submit').innerHTML = 'LOGIN';
                            /*document.getElementById('msg').innerHTML = "Usuário ou senha incorretos.";
                            $("#submit").val('Login');
                            setTimeout(function() {
                                document.getElementById('msg').innerHTML = "Você deve logar com sua conta do suap.";
                            }, 5000);*/
                        }
                    },
                    error: function(st, error){
                        console.log(error);
                    }
                });
            }
        });
    }
});