let user = window.localStorage.getItem("username");
let pass = window.localStorage.getItem("password");

function getData(t, ano, periodo, callback){

    var dataString="username="+user+"&password="+pass+"&login=&type="+t+"&anoletivo="+ano+"&periodoletivo="+periodo;
        
    var dados = "";
    
     $.ajax({
        type: "POST",
        url: "http://azanbertre.com/projetointegrador/pages/sendData.php",
        data: dataString,
        datatype: "JSON",
        crossDomain: true,
        cache: false,
        success: callback
    });
    //return dados;
}