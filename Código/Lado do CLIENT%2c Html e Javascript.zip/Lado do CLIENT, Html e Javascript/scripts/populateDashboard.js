function populateDashboard(){
    var d = window.localStorage.getItem('dados');
    var dados = JSON.parse(d);

    var n = window.localStorage.getItem('notas');
    var notas = JSON.parse(n);

    let nome = document.createElement('P'); nome.innerHTML = 'Nome: ' + dados.nome_usual;
    let matricula = document.createElement('P'); matricula.innerHTML = 'Matricula: ' + dados.matricula;
    let email = document.createElement('P'); email.innerHTML = 'E-mail: ' + dados.email;
    let curso = document.createElement('P'); curso.innerHTML = 'Cursando: ' + dados.vinculo.curso;
    let vinculo = document.createElement('P'); vinculo.innerHTML = 'Vinculo: ' + dados.tipo_vinculo;

    createCard('DADOS', new Array(nome, matricula, email, curso, vinculo), false, false);

    ///////////////////////////// -------------------------- ////////////////////////////////////
    
    let n_materia = '';
    let n_mMateria = '';
    let pior_nota = 100;
    let melhor_nota = 0;

    let total_faltas = 0;

    let horas_cumpridas = 0;
    let porcentagem_faltas = 100;

    $.each(notas, function(i, materia){
        let m = materia.media_final_disciplina;
        if(parseInt(m) < pior_nota){
            pior_nota = m;
            n_materia = materia.disciplina;
        }
        if(parseInt(m) > melhor_nota){
            melhor_nota = m;
            n_mMateria = materia.disciplina;
        }


        horas_cumpridas += materia.carga_horaria_cumprida;
        total_faltas += materia.numero_faltas;
    });

    let p = (total_faltas * 100) / horas_cumpridas;
    porcentagem_faltas -= p;

    let nome_Mmateria = document.createElement('P'); nome_Mmateria.innerHTML = (n_mMateria.split("-")[1]).split("(")[0];
    createCard('MATÉRIA COM MELHOR MÉDIA', new Array(nome_Mmateria), true, false);

    let nome_materia = document.createElement('P'); nome_materia.innerHTML = (n_materia.split("-")[1]).split("(")[0];
    createCard('MATÉRIA COM PIOR MÉDIA', new Array(nome_materia), true, false);

    ///////////////////////////////////////////////////////////////////////////////////////

    let n_faltas = document.createElement('P'); n_faltas.innerHTML = total_faltas;
    createCard('TOTAL DE FALTAS', new Array(n_faltas), true, false);

    let p_faltas = document.createElement('P'); p_faltas.innerHTML = parseFloat(porcentagem_faltas).toFixed(2) + '%';
    createCard('PRESENÇA GERAL', new Array(p_faltas), true, false);
}

$('document').ready(function(){
    if(window.localStorage.getItem('notas') != null & window.localStorage.getItem('dados') != null){
        populateDashboard();
    }
});