document.write('\
<div id="menu-header">\
    <p id="menu-page-name"></p>\
</div>\
\
\
<div id="menu-container">\
    <div id="hidden-menu">\
        <p id="user-nome"></p>\
\
        <div id="menu-buttons">\
            <div class="menu-button" id="dashboard">Dashboard</div>\
            <div class="menu-button" id="notas">Notas</div>\
            <div class="menu-button"></div>\
        </div>\
\
        <button id="logoff" onclick="doLogoff()">Logoff</button>\
    </div>\
    <div id="showed-menu">\
        <div id="open-close-menu"></div>\
        <div id="user-photo">\
            <button id="user-photo-img"></button>\
        </div>\
    </div>\
</div>')