$(document).ready(function(){

    //Função para mudar a página ao clicar em botões do menu.
    function setNewPage(title, src){
        var page = document.getElementById("iframe").src;
        var p = page.split("/").slice(-1)[0];
        if(p != src.split("/").slice(-1)[0]){
            document.getElementById('menu-page-name').innerHTML = title;
            document.getElementById('iframe').src = src;
        }
        closeMenu();
    }

    function postToIframe(data,url,target){
        $('body').append('<form action="'+url+'" method="post" target="'+target+'" id="postToIframe"></form>');
        $.each(data,function(n,v){
            $('#postToIframe').append('<input type="hidden" name="'+n+'" value="'+v+'" />');
        });
        $('#postToIframe').submit().remove();
    }

    //Configuração de botões do menu.
    $("#dashboard").click(function(){
        setNewPage("DASHBOARD", "../pages/dashboard.html");
    });
    $("#notas").click(function(){
        setNewPage("NOTAS", "../pages/notas.html");
    });
    /*$("#materiais").click(function(){
        setNewPage("Materiais", "../pages/materiais.html");
    });*/
    $("#forum").click(function(){
        setNewPage("FÓRUM", "http://azanbertre.com/forum/signin.php");
        var user = window.localStorage.getItem("username");
        var pass = window.localStorage.getItem("password");
        postToIframe({username:user,password:pass},"http://azanbertre.com/forum/signin.php",'iframe');

    });
    //Fechar o menu caso haja click fora dele.
    var closed = false;
    $('#iframe').contents().on('click', 'body', function(){
        closeMenu();
    });
    $("#menu-background").click(function(e) {
        closeMenu();
    });

    function toggleMenu(){
        $("#menu-container").toggleClass("open");
    }

    function closeMenu(){
        $("#menu-container").css("-webkit-transform", "translate3d(0, 0, 0)");
        $("#menu-container").css("transform", "translate3d(0, 0, 0)");
        $("#menu-background").removeClass("active");
    }
    function openMenu(){
        $("#menu-container").css("-webkit-transform", "translate3d(var(--menu-width), 0, 0)");
        $("#menu-container").css("transform", "translate3d(var(--menu-width), 0, 0)");
        $("#menu-background").addClass("active");
    }

    //Fechar e abrir menu ao apertar o botão de hamburguer.
    $("#toggle-menu").click(function(){
        openMenu();
    });

    //Valor inicial do nome de página atual.
    document.getElementById('menu-page-name').innerHTML = "DASHBOARD";
});