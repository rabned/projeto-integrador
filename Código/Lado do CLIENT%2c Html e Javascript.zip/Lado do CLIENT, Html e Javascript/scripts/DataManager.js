var atualizados = 0;

//Atualiza todos os dados incluindo dashboard e notas.
function atualizar_dados(){
    document.getElementById('loader').className = 'active';

    //Pega os periodos letivos do aluno.
    var anoLetivo = 0;
    getData(4, 2010, 1, function(p){
        periodos = JSON.parse(p.substring(1));
        anoLetivo = periodos[periodos.length-1].ano_letivo;

        window.localStorage.setItem('ano_letivo', anoLetivo);

        atualizar();

        //Pega os dados de nota do aluno.
        getData(1, anoLetivo, 1, function(n){
            notas = JSON.parse(n.substring(1));
            window.localStorage.setItem('notas', JSON.stringify(notas));

            atualizar();
        });

        //Pega os dados básicos do aluno.
        getData(0, anoLetivo, 1, function(data){
            dados = JSON.parse(data.substring(1));
            window.localStorage.setItem('dados', JSON.stringify(dados));

            atualizar();
        });
    });
}

function atualizar(){
    atualizados++;
    if (atualizados > 2) {
        populate();
        atualizados = 0;
    }
    console.log(atualizados);
}

function populate(){
    //document.getElementById('user-photo-img').style.backgroundImage = "url('https://suap.ifrn.edu.br" + dados.url_foto_75x100+"')";
    document.getElementById('iframe').src = '../pages/dashboard.html';
    document.getElementById('user-nome').innerHTML = dados.vinculo.nome;

    $('#loader').removeClass('active');
}

function getTurma(id){
    
}

$('document').ready(function(){
    atualizar_dados();
});