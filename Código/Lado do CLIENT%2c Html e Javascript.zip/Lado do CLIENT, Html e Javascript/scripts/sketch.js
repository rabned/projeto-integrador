function setup(){
    createCanvas(windowWidth, windowHeight);

    background(0);
    fullscreen(true);
}

function draw(){
    
}

function touchMoved(){
    strokeWeight(10);
    stroke(255)
    line(mouseX, mouseY, pmouseX, pmouseY);
    return false;
}