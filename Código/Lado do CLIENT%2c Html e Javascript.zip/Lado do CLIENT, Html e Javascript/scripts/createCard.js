function createCard(header_name, cont, content_centered, has_footer, footer_content){
    var card = document.createElement('DIV'); card.className = 'card';
    var header = document.createElement('DIV'); header.className = 'card-header';
    var content = document.createElement('DIV'); 

    var header_n = document.createElement('P'); header_n.innerHTML = header_name;
    header_n.style.margin = 0;

    cont.forEach(function(el) {
        content.appendChild(el);
    }, this);

    if (content_centered){
        content.style.textAlign = 'center';
    }

    if(has_footer){
        content.className = 'card-content-footer';
    }else{
        content.className = 'card-content';
    }

    header.appendChild(header_n);
    card.appendChild(header);
    card.appendChild(content);
    
    if(has_footer){
        var footer = document.createElement('DIV'); footer.className = 'card-footer';
        var footer_n = document.createElement('P'); footer_n.innerHTML = footer_content;
        footer_n.style.margin = 0;

        footer.appendChild(footer_n);
        card.appendChild(footer);
    }

    document.getElementById('data').appendChild(card);
}