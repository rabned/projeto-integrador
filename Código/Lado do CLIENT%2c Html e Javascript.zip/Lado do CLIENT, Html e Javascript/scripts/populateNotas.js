function atualizarNotas(){
    //Função de pegar dados.
    getData(1, 2017, 1, function(data){
        //Recebe json com os dados.
        var dados = JSON.parse(data.substring(1));

        //Salva dados localmente.
        window.localStorage.setItem('notas', JSON.stringify(dados));

        //Em caso da página estar preenchida, deletar tudo.
        $('.card').remove();
        //Preencher a página.
        populateNotas();
    });
}

function populateNotas(){
    var notas = window.localStorage.getItem('notas');
    var dados = JSON.parse(notas);

    $.each(dados, function(i, materia){
        // Dados básicos.
        var nome = document.createElement('P'); nome.innerHTML = materia.disciplina;
        
        var nota_1 = document.createElement('P'); nota_1.innerHTML = "Nota 1: "+(materia.nota_etapa_1.nota == null ? 'Não Colocada' : materia.nota_etapa_1.nota);
        var nota_2 = document.createElement('P'); nota_2.innerHTML = "Nota 2: "+(materia.nota_etapa_2.nota == null ? 'Não Colocada' : materia.nota_etapa_2.nota);
        var nota_3 = document.createElement('P'); nota_3.innerHTML = "Nota 3: "+(materia.nota_etapa_3.nota == null ? 'Não Colocada' : materia.nota_etapa_3.nota);
        var nota_4 = document.createElement('P'); nota_4.innerHTML = "Nota 4: "+(materia.nota_etapa_4.nota == null ? 'Não Colocada' : materia.nota_etapa_4.nota);
        
        var media_geral = document.createElement('P'); media_geral.innerHTML = "Média: "+(materia.media_final_disciplina == null ? 0 : materia.media_final_disciplina);
        var faltas = document.createElement('P'); faltas.innerHTML = "Faltas: "+materia.numero_faltas;

        var necessario_para_passar = "";

        //Cálculos de nota.
        //Se não estiver aprovado.
        if(materia.situacao != "Aprovado"){
            //Notas insuficientes para matéria anual ou semestral.
            if((materia.nota_etapa_1.nota == null | materia.nota_etapa_2.nota == null) & materia.nota_etapa_3.nota == null & materia.nota_etapa_4.nota == null){
                necessario_para_passar = "Notas insuficientes para cálculo.";
            }
            //Cálculo para matéria anual com os 2 primeiros bimestres com nota.
            else if((materia.nota_etapa_1.nota != null & materia.nota_etapa_2.nota != null) & materia.nota_etapa_3.nota == null & materia.nota_etapa_4.nota == null){
                //Váriavel de total de pesos.
                var n = (materia.nota_etapa_1.nota * 2) + (materia.nota_etapa_2.nota * 2);
                //Resto necessário para passar.
                var rest = ((600 - n) / 2) / 3;
    
                necessario_para_passar = "Você precisa de " + Math.round(rest.toFixed()) + " no 3º e 4º bimestres.";
            }
            //Cálculo para matéria anual com os 3 primeiros bimestres com nota.
            else if(materia.nota_etapa_1.nota != null & materia.nota_etapa_2.nota != null & materia.nota_etapa_3.nota != null & materia.nota_etapa_4.nota == null){
                //Váriavel de total de pesos.
                var n = (materia.nota_etapa_1.nota * 2) + (materia.nota_etapa_2.nota * 2) + (materia.nota_etapa_3.nota * 3);
                //Resto necessário para passar.
                var rest = (600 - n) / 3;

                //Se está aprovado já no 3º bimestre.
                if(n >= 600){
                    necessario_para_passar = "Você já foi aprovado(a) no 3º bimestre!!.";
                }
                //Se não estiver, mostrar o que falta para passar.
                else{
                    necessario_para_passar = "Você precisa de "+ Math.round(rest.toFixed()) + " no 4º bimestre.";
                }
            }
            else if(materia.nota_etapa_1.nota != null & materia.nota_etapa_2.nota == null & materia.nota_etapa_3.nota != null & materia.nota_etapa_4.nota == null){
                //Váriavel de total de pesos
                var n = (materia.nota_etapa_1.nota * 2) + (materia.nota_etapa_3.nota * 3);
                //Resto necessário para passar
                var rest = ((600 - n) / 5);

                necessario_para_passar = "Você precisa de " + Math.round(rest.toFixed()) + " no 2º e 4º bimestres.";
            }
            
            else if(materia.media_final_disciplina >= 60){
                necessario_para_passar = "Parabéns, você está aprovado(a)!";
            }
            //Cálculo para matéria anual para a prova final.
            else{
                //ajeitar depois
                var rest = (120 - materia.media_final_disciplina);
                necessario_para_passar = "Você precisa de " + Math.round(rest.toFixed()) + " na prova final.";
            }

            //Se a matéria é semestral.
            if(materia.quantidade_avaliacoes < 3){
                //Primeiro Semestre
                if(true){
                    if(materia.nota_etapa_1.nota != null & materia.nota_etapa_2.nota == null){
                        var n = (materia.nota_etapa_1.nota * 2);
                        var rest = (300 - n) / 3;

                        necessario_para_passar = "Você precisa de " + Math.round(rest.toFixed()) + " no 2º bimestre.";
                    }
                }
                //Segundo Semestre
                else{
                    if(materia.nota_etapa_3.nota != null & materia.nota_etapa_4.nota == null){
                        var n = (materia.nota_etapa_3.nota * 2) + (materia.nota_etapa_4.nota * 3);
                        var rest = (300 - n) / 2;

                        necessario_para_passar = "Você precisa de " + Math.round(rest.toFixed()) + " no 4º bimestre.";
                    }
                }
            }
        }
        //Se estiver aprovado.
        else{
            necessario_para_passar = "Parabéns, você está aprovado(a)!";
        }

        //Simplificar nome da matéria com split.
        var nome_materia = (materia.disciplina.split("-")[1]).split("(")[0];
        
        var percentual_presenca = document.createElement('P'); percentual_presenca.innerHTML = "Presença: " + materia.percentual_carga_horaria_frequentada + "%";

        //Criação de elementos contendo os dados calculados.
        //Matéria Semestral.
        if(materia.quantidade_avaliacoes == 2){
            //Primeiro Semestre.
            if(true){
                createCard(nome_materia, new Array(nota_1, nota_2, faltas, percentual_presenca, media_geral), false, true, necessario_para_passar);
            }
            //Segundo Semestre. 
            //else{
            //    nota_3.innerHTML = "Nota 1: "+(materia.nota_etapa_3.nota == null ? 'Não Colocada' : materia.nota_etapa_3.nota);
            //    nota_4.innerHTML = "Nota 2: "+(materia.nota_etapa_4.nota == null ? 'Não Colocada' : materia.nota_etapa_4.nota);
            //    createCard(nome_materia, new Array(nota_3, nota_4, faltas, percentual_presenca, media_geral), false, true, necessario_para_passar);
            //}
        }
        //Matéria Anual
        else{
            createCard(nome_materia, new Array(nota_1, nota_2, nota_3, nota_4, faltas, percentual_presenca, media_geral), false, true, necessario_para_passar);
        }
    });
}

$('document').ready(function(){
    //Dados salvos localmente.
    if(window.localStorage.getItem('notas') != null){
        populateNotas();
    }
    //Dados ainda não encontrados localmente.
    else{
        //Se estiver conectado.
        if(navigator.onLine){
            //Pegar dados do servidor.
            atualizarNotas();
        }
    }
});